window.addEventListener('DOMContentLoaded', () => {
	document.body.style.overflow = 'auto'

	const COMPANIES_URL = './js/companies.json'

	const userTradesCount = document.querySelectorAll('[data-successfull-trades]')
	const userBalance = document.querySelectorAll('[data-user-balance]')
	const startTradingButton = getDOMElement('[data-start-trading-button]')
	const stopTradingButton = getDOMElement('[data-stop-trading-button]')
	const modalFirstLogin = getDOMElement('[data-new-user')
	const modalError = getDOMElement('[data-chart-error]')
	const modalTradeStarted = getDOMElement('[data-modal-start]')
	const title = getDOMElement('[data-title]')
	const hint = getDOMElement('[data-hint]')

	const btnShowForm = getDOMElement('.button-show-form')
	const modalForm = getDOMElement('[modal-form]')
	const formElement = document.getElementById('reg_form')
	const beforeForm = getDOMElement('[data-before-form')

	const defaultTitle = `нажмите <span>"Торговать"</span> для начала автоматических торгов на биржевом рынке`
	const startedTitle = 'Программа работает в автоматическом режиме'

	setTimeout(() => {
		showModal(hint)
	}, 10000)

	function hideModal(modal) {
		modal.classList.remove('_show')
		modal.classList.add('_hide')
	}

	function showModal(modal) {
		modal.classList.remove('_hide')
		modal.classList.add('_show')
	}

	function handleFirstLogin() {
		modalFirstLogin.classList.add('_hide_visibility')
		modalFirstLogin.addEventListener('animationend', () => {
			modalFirstLogin.classList.add('_hide')
			modalFirstLogin.classList.add('_hide_visibility')
			modalFirstLogin.classList.remove('_show')
			document.body.style.overflow = 'auto'
		})
	}

	if (!localStorage.getItem('logged') || localStorage.getItem('logged') !== 'true') {
		document.body.style.overflow = 'hidden'
		showModal(modalFirstLogin)
		getDOMElement('.modal--button-start').addEventListener('click', () => {
			localStorage.setItem('logged', true)
			localStorage.setItem('balance', 250)
			localStorage.setItem('successfullTradesCount', 0)
			handleFirstLogin()
		})
	}

	// let successfullTradesCount = 0

	let successfullTradesCount = isNaN(parseInt(localStorage.getItem('successfullTradesCount')))
		? 0
		: parseInt(localStorage.getItem('successfullTradesCount'))
	let balance = isNaN(parseInt(localStorage.getItem('balance')))
		? 250
		: parseInt(localStorage.getItem('balance'))

	function updateUserData() {
		userBalance.forEach((current) => (current.innerHTML = `${balance} €`))
		userTradesCount.forEach((trades) => (trades.innerHTML = successfullTradesCount))
	}
	updateUserData()

	function getDOMElement(element) {
		return document.querySelector(element)
	}

	async function getCompanies() {
		try {
			const response = await fetch(COMPANIES_URL)

			if (!response.ok) {
				const message = `Error ${response.status}`
				console.error(message)
			}

			const companies = await response.json()
			const random = Math.floor(Math.random() * companies.corporations.length)
			return companies.corporations[random].symbol
		} catch (err) {
			/*showModal(modalError)*/
			console.error(err)
		}
	}

	function setBalanceToLocalStorage(balanceValue) {
		balance = balanceValue
		localStorage.setItem('balance', balanceValue)
		updateUserData()
	}

	function setSuccessfullTradeToLocalStorage(tradesCount) {
		successfullTradesCount = tradesCount
		localStorage.setItem('successfullTradesCount', tradesCount)
		updateUserData()
	}

	// make toggle function for single deal (dont't care lose or win)

	function randomBuySell() {
		const randomChance = Math.floor(Math.random() * 100)
		return randomChance > 50 ? 'Покупка' : 'Продажа'
	}

	function tradeStatus(trade) {
		return trade ? 'success--trade' : 'lost--trade'
	}

	async function toggleModal(modalSelector, value, word, status) {
		showModal(modalSelector)
		modalSelector.querySelector(
			'[data-trade-value]'
		).innerHTML = `Вы ${word} <span class="value">${value} €</span>`
		hideModal(hint)
		const symbol = await getCompanies()
		const li = `
			<li class="li--deal li__${tradeStatus(status)}">
				<span class="row--company">${symbol}</span>
				<span class="row--">${randomBuySell()}</span>
				<span>${Math.floor(value / 3)} €</span>
				<span>${status ? 'успешно' : 'неудача'}</span>
				<span class="row__${tradeStatus(status)}">
					${status ? '+' : '-'} ${value} €
				</span>
			</li>`

		getDOMElement('[data-latest-transactions]').insertAdjacentHTML('beforeend', li)

		setTimeout(() => {
			modalSelector.classList.add('_hide_visibility')
			modalSelector.addEventListener('animationend', () => {
				modalSelector.classList.remove('_hide_visibility')
				hideModal(modalSelector)
			})
		}, 2000)
	}

	function profitableDeal() {
		const modalWin = getDOMElement('[data-modal-win]')
		const randomProfit = Math.floor(Math.random() * 150) + 1
		balance += randomProfit
		setBalanceToLocalStorage(balance)

		// set successfull trades count
		successfullTradesCount++
		setSuccessfullTradeToLocalStorage(successfullTradesCount)

		toggleModal(modalWin, randomProfit, 'заработали', true)
		return balance
	}

	function losingDeal() {
		const modalLose = getDOMElement('[data-modal-lose]')
		const randomLose = Math.floor(Math.random() * 40) + 1
		balance -= randomLose
		setBalanceToLocalStorage(balance)
		toggleModal(modalLose, randomLose, 'потеряли', false)
		return balance
	}

	function startTrading() {
		const randomChance = Math.floor(Math.random() * 100)
		return randomChance > 20 ? profitableDeal() : losingDeal()
	}

	function handleTotalProfit() {
		getDOMElement('[data-earned-money]').innerHTML = `${balance - 250} €`
	}

	let interval
	let formTimeout
	const timer = 30 * 1000

	startTradingButton.addEventListener('click', (e) => {
		title.innerHTML = startedTitle
		showModal(modalTradeStarted)
		setTimeout(() => hideModal(modalTradeStarted), 2000)
		interval = setInterval(startTrading, 5000)
		e.target.disabled = true
		hideModal(hint)
		setTimeout(() => (stopTradingButton.disabled = false), 10000)

		formTimeout = setTimeout(() => {
			showModal(modalForm)
			clearInterval(interval)
			handleTotalProfit()
			localStorage.setItem('expired', true)
			lockScreen()
		}, timer)
	})

	stopTradingButton.addEventListener('click', (e) => {
		title.innerHTML = defaultTitle
		clearInterval(interval)
		clearTimeout(formTimeout)
		e.target.disabled = true
		localStorage.setItem('expired', true)
		lockScreen()
		setTimeout(() => (startTradingButton.disabled = false), 10000)
	})

	btnShowForm.addEventListener('click', handleShowForm)

	function handleShowForm(e) {
		e.preventDefault()
		hideModal(beforeForm)
		showModal(formElement)
	}

	function lockScreen() {
		let expired = localStorage.getItem('expired')

		if (expired || balance >= 501) {
			document.body.style.overflow = 'hidden'
			showModal(modalForm)
			clearInterval(interval)
			clearTimeout(formTimeout)
			handleTotalProfit()
		}
	}

	lockScreen()
})
