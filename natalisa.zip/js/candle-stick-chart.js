
async function getCryptoCandles() {
    try {
        const symbol = 'BTCUSDT'
        const interval = '5m'

        const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}`)
        const data = await response.json()

        const candles = data.map(candle => ({
            x: new Date(candle[0]),
            y: [
                parseFloat(candle[1]),
                parseFloat(candle[2]),
                parseFloat(candle[3]),
                parseFloat(candle[4]),
            ]
        }))

        const options = {
            chart: {
                type: 'candlestick',
                height: 400,
            },
            series: [{
                data: candles,
            }],
            xaxis: {
                type: 'datetime',
            }
        }

        const chart = new ApexCharts(document.querySelector('#chart'), options)
        chart.render()
    } catch (error) {
        document.querySelector('[data-chart-error]').classList.remove('_hide')
        document.querySelector('[data-chart-error]').classList.add('_show')
        console.error('Произошла ошибка при получении данных свечей:', error)
    }
}

getCryptoCandles()
