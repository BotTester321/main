<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <!--metatextblock-->
    <title>Спасибо!</title>
    <meta property="og:url" content="thank" />
    <meta property="og:title" content="Спасибо!" />
    <meta property="og:description" content="" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="thsfiles/images/tild3466-3630-4535-b865-643936376334____2022-10-26__153447.png" />
    <link rel="canonical" href="thank"><!--/metatextblock-->
    <meta name="format-detection" content="telephone=no" />
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <link rel="dns-prefetch" href="https://ws.tildacdn.com">
    <link rel="shortcut icon" href="thsfiles/images/tild3764-6461-4233-b931-656136333438__favicon.ico" type="image/x-icon" /><!-- Assets -->
    <script src="https://neo.tildacdn.com/js/tilda-fallback-1.0.min.js" charset="utf-8" async></script>
    <link rel="stylesheet" href="thsfiles/css/tilda-grid-3.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';" />
    <link rel="stylesheet" href="thsfiles/css/tilda-blocks-page33953345.min.css?t=1676458610" type="text/css" media="all" onerror="this.loaderr='y';" />
    <link rel="stylesheet" href="thsfiles/css/fonts-tildasans.css" type="text/css" media="all" onerror="this.loaderr='y';" />
    <script type="text/javascript">(function (d) {
            if (!d.visibilityState) {
                var s = d.createElement('script');
                s.src = 'js/tilda-polyfill-1.0.min.js';
                d.getElementsByTagName('head')[0].appendChild(s);
            }
        })(document);
        function t_onReady(func) {
            if (document.readyState != 'loading') {
                func();
            } else {
                document.addEventListener('DOMContentLoaded', func);
            }
        }
        function t_onFuncLoad(funcName, okFunc, time) {
            if (typeof window[funcName] === 'function') {
                okFunc();
            } else {
                setTimeout(function () {
                    t_onFuncLoad(funcName, okFunc, time);
                }, (time || 100));
            }
        } function t396_initialScale(t) { var e = document.getElementById("rec" + t); if (e) { var r = e.querySelector(".t396__artboard"); if (r) { var a, i = document.documentElement.clientWidth, l = [], d = r.getAttribute("data-artboard-screens"); if (d) { d = d.split(","); for (var o = 0; o < d.length; o++)l[o] = parseInt(d[o], 10) } else l = [320, 480, 640, 960, 1200]; for (o = 0; o < l.length; o++) { var n = l[o]; n <= i && (a = n) } var g = "edit" === window.allrecords.getAttribute("data-tilda-mode"), u = "center" === t396_getFieldValue(r, "valign", a, l), c = "grid" === t396_getFieldValue(r, "upscale", a, l), t = t396_getFieldValue(r, "height_vh", a, l), f = t396_getFieldValue(r, "height", a, l), e = !!window.opr && !!window.opr.addons || !!window.opera || -1 !== navigator.userAgent.indexOf(" OPR/"); if (!g && u && !c && !t && f && !e) { for (var s = parseFloat((i / a).toFixed(3)), _ = [r, r.querySelector(".t396__carrier"), r.querySelector(".t396__filter")], o = 0; o < _.length; o++)_[o].style.height = parseInt(f, 10) * s + "px"; for (var h = r.querySelectorAll(".t396__elem"), o = 0; o < h.length; o++)h[o].style.zoom = s } } } } function t396_getFieldValue(t, e, r, a) { var i = a[a.length - 1], l = r === i ? t.getAttribute("data-artboard-" + e) : t.getAttribute("data-artboard-" + e + "-res-" + r); if (!l) for (var d = 0; d < a.length; d++) { var o = a[d]; if (!(o <= r) && (l = o === i ? t.getAttribute("data-artboard-" + e) : t.getAttribute("data-artboard-" + e + "-res-" + o))) break } return l }</script>
    <script src="js/jquery-1.10.2.min.js" charset="utf-8" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-scripts-3.0.min.js" charset="utf-8" defer onerror="this.loaderr='y';"></script>
    <script src="js/tilda-blocks-page33953345.min.js?t=1676458610" charset="utf-8" async onerror="this.loaderr='y';"></script>
    <script src="js/lazyload-1.3.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script>
    <script src="js/tilda-zero-1.1.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script>
    <script src="js/tilda-zero-scale-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script>
    <script src="js/tilda-events-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script>
    <script type="text/javascript">window.dataLayer = window.dataLayer || [];</script>
    <script type="text/javascript">(function () {
            if ((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent)) === false && typeof (sessionStorage) != 'undefined' && sessionStorage.getItem('visited') !== 'y' && document.visibilityState) {
                var style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = '@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';
                document.getElementsByTagName('head')[0].appendChild(style);
                function t_setvisRecs() {
                    var alr = document.querySelectorAll('.t-records');
                    Array.prototype.forEach.call(alr, function (el) {
                        el.classList.add("t-records_animated");
                    });
                    setTimeout(function () {
                        Array.prototype.forEach.call(alr, function (el) {
                            el.classList.add("t-records_visible");
                        });
                        sessionStorage.setItem("visited", "y");
                    }, 400);
                }
                document.addEventListener('DOMContentLoaded', t_setvisRecs);
            }
        })();</script>
        
        

        
        
    
    
    <!-- Meta Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '176535675542426');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=176535675542426&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->
    
    
    
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P5TQZ59G');</script>



    <!--allrecords--><div id="allrecords" data-tilda-export="yes" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="6786950" data-tilda-page-id="33953345" data-tilda-page-alias="thank" data-tilda-formskey="f27b78d49d8533f3a4af3dab96786950" data-tilda-imgoptimoff="yes" data-tilda-lazy="yes" data-tilda-project-headcode="yes">
        <div id="rec548703988" class="r t-rec" style=" " data-animationappear="off" data-record-type="396">
            <!-- T396 -->
            <style>
                #rec548703988 .t396__artboard {
                    min-height: 650px;
                    height: 100vh;
                    background-color: #ffffff;
                }

                #rec548703988 .t396__filter {
                    min-height: 650px;
                    height: 100vh;
                    background-image: -webkit-gradient( linear, left top, left bottom, from(rgba(0,0,0,0.3)), to(rgba(0,0,0,0.35)) );
                    background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.3), rgba(0,0,0,0.35));
                    background-image: linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.35));
                    will-change: transform;
                }

                #rec548703988 .t396__carrier {
                    min-height: 650px;
                    height: 100vh;
                    background-position: center center;
                    background-attachment: scroll;
                    background-image: url('thsfiles/images/tild3733-3839-4035-b733-393332393335__22_ilonmask.jpeg');
                    background-size: cover;
                    background-repeat: no-repeat;
                }

                @media screen and (max-width: 1199px) {
                    #rec548703988 .t396__artboard {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__filter {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__carrier {
                        min-height: 550px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec548703988 .t396__artboard {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__filter {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__carrier {
                        min-height: 550px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec548703988 .t396__artboard {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__filter {
                        min-height: 550px;
                    }

                    #rec548703988 .t396__carrier {
                        min-height: 550px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec548703988 .t396__artboard {
                        min-height: 450px;
                    }

                    #rec548703988 .t396__filter {
                        min-height: 450px;
                    }

                    #rec548703988 .t396__carrier {
                        min-height: 450px;
                        background-attachment: scroll;
                    }
                }

                #rec548703988 .tn-elem[data-elem-id="1666695981620"] {
                    z-index: 5;
                    top: calc(50vh - 325px + 231px);
                    left: calc(50% - 600px + 469px);
                    width: 262px;
                }

                    #rec548703988 .tn-elem[data-elem-id="1666695981620"] .tn-atom {
                        background-position: center center;
                        border-color: transparent;
                        border-style: solid;
                    }

                @media screen and (max-width: 1199px) {
                    #rec548703988 .tn-elem[data-elem-id="1666695981620"] {
                        top: 188px;
                        left: calc(50% - 480px + 344px);
                        width: 272px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec548703988 .tn-elem[data-elem-id="1666695981620"] {
                        top: 171px;
                        left: calc(50% - 320px + 184px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec548703988 .tn-elem[data-elem-id="1666695981620"] {
                        top: 173px;
                        left: calc(50% - 240px + 104px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec548703988 .tn-elem[data-elem-id="1666695981620"] {
                        top: 168px;
                        left: calc(50% - 160px + 49px);
                        width: 222px;
                    }
                }

                #rec548703988 .tn-elem[data-elem-id="1666697581707"] {
                    color: #333333;
                    text-align: center;
                    z-index: 10;
                    top: calc(50vh - 325px + 314px);
                    left: calc(50% - 600px + 189px);
                    width: 822px;
                }

                    #rec548703988 .tn-elem[data-elem-id="1666697581707"] .tn-atom {
                        color: #333333;
                        font-size: 34px;
                        font-family: 'Ubuntu',Arial,sans-serif;
                        line-height: 1.25;
                        font-weight: 700;
                        background-position: center center;
                        border-color: transparent;
                        border-style: solid;
                    }

                @media screen and (max-width: 1199px) {
                    #rec548703988 .tn-elem[data-elem-id="1666697581707"] {
                        top: 275px;
                        left: calc(50% - 480px + 265px);
                        width: 431px;
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666697581707"] .tn-atom {
                            font-size: 32px;
                        }
                }

                @media screen and (max-width: 959px) {
                    #rec548703988 .tn-elem[data-elem-id="1666697581707"] {
                        top: 264px;
                        left: calc(50% - 320px + 105px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec548703988 .tn-elem[data-elem-id="1666697581707"] {
                        top: 253px;
                        left: calc(50% - 240px + 25px);
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666697581707"] .tn-atom {
                            font-size: 26px;
                        }
                }

                @media screen and (max-width: 479px) {
                    #rec548703988 .tn-elem[data-elem-id="1666697581707"] {
                        top: 233px;
                        left: calc(50% - 160px + -14px);
                        width: 348px;
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666697581707"] .tn-atom {
                            font-size: 22px;
                        }
                }

                #rec548703988 .tn-elem[data-elem-id="1666720340242"] {
                    color: #333333;
                    text-align: center;
                    z-index: 12;
                    top: calc(50vh - 325px + 370px);
                    left: calc(50% - 600px + 381px);
                    width: 439px;
                }

                    #rec548703988 .tn-elem[data-elem-id="1666720340242"] .tn-atom {
                        color: #333333;
                        font-size: 25px;
                        font-family: 'Ubuntu',Arial,sans-serif;
                        line-height: 1.25;
                        font-weight: 300;
                        background-position: center center;
                        border-color: transparent;
                        border-style: solid;
                    }

                @media screen and (max-width: 1199px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720340242"] {
                        top: 325px;
                        left: calc(50% - 480px + 265px);
                        width: 431px;
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666720340242"] .tn-atom {
                            font-size: 22px;
                        }
                }

                @media screen and (max-width: 959px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720340242"] {
                        top: 319px;
                        left: calc(50% - 320px + 105px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720340242"] {
                        top: 297px;
                        left: calc(50% - 240px + 67px);
                        width: 346px;
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666720340242"] .tn-atom {
                            font-size: 18px;
                        }
                }

                @media screen and (max-width: 479px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720340242"] {
                        top: 273px;
                        left: calc(50% - 160px + 26px);
                        width: 268px;
                    }

                        #rec548703988 .tn-elem[data-elem-id="1666720340242"] .tn-atom {
                            font-size: 18px;
                        }
                }

                #rec548703988 .tn-elem[data-elem-id="1666720384225"] {
                    z-index: 3;
                    top: calc(50vh - 325px + 141px);
                    left: calc(50% - 600px + 286px);
                    width: 629px;
                    height: 369px;
                }

                    #rec548703988 .tn-elem[data-elem-id="1666720384225"] .tn-atom {
                        border-radius: 20px;
                        background-color: #ffffff;
                        background-position: center center;
                        border-color: transparent;
                        border-style: solid;
                    }

                @media screen and (max-width: 1199px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720384225"] {
                        top: 124px;
                        left: calc(50% - 480px + 208px);
                        width: 545px;
                        height: 313px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720384225"] {
                        top: 119px;
                        left: calc(50% - 320px + 48px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720384225"] {
                        top: 129px;
                        left: calc(50% - 240px + 9px);
                        width: 463px;
                        height: 265px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec548703988 .tn-elem[data-elem-id="1666720384225"] {
                        top: 131px;
                        left: calc(50% - 160px + 5px);
                        width: 310px;
                        height: 223px;
                    }
                }
            </style><div class='t396'>
                <div class="t396__artboard" data-artboard-recid="548703988" data-artboard-screens="320,480,640,960,1200" data-artboard-height="650" data-artboard-valign="center" data-artboard-height_vh="100" data-artboard-upscale="grid" data-artboard-height-res-320="450" data-artboard-height-res-480="550" data-artboard-height-res-640="550" data-artboard-height-res-960="550">
                    <div class="t396__carrier t-bgimg" data-artboard-recid="548703988" src="thsfiles/images/tild3733-3839-4035-b733-393332393335__22_ilonmask.jpeg" data-original="thsfiles/images/tild3733-3839-4035-b733-393332393335__22_ilonmask.jpeg"></div><div class="t396__filter" data-artboard-recid="548703988"></div><div class='t396__elem tn-elem tn-elem__5487039881666695981620' data-elem-id='1666695981620' data-elem-type='image' data-field-top-value="231" data-field-left-value="469" data-field-width-value="262" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="192" data-field-fileheight-value="28" data-field-top-res-320-value="168" data-field-left-res-320-value="49" data-field-width-res-320-value="222" data-field-top-res-480-value="173" data-field-left-res-480-value="104" data-field-top-res-640-value="171" data-field-left-res-640-value="184" data-field-top-res-960-value="188" data-field-left-res-960-value="344" data-field-width-res-960-value="272">
                    
                    
                    <div class='tn-atom'>
                    
                    <img class='tn-atom__img t-img' src="thanklogo.png" data-original='thanklogo.png' imgfield='tn_img_1666695981620'>
                    
                    
                    </div></div> 
                    
                    
                    <div class='t396__elem tn-elem tn-elem__5487039881666697581707' data-elem-id='1666697581707' data-elem-type='text' data-field-top-value="314" data-field-left-value="189" data-field-width-value="822" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="233" data-field-left-res-320-value="-14" data-field-width-res-320-value="348" data-field-top-res-480-value="253" data-field-left-res-480-value="25" data-field-top-res-640-value="264" data-field-left-res-640-value="105" data-field-top-res-960-value="275" data-field-left-res-960-value="265" data-field-width-res-960-value="431"><div class='tn-atom' field='tn_text_1666697581707'>Спасибо за обращение! </div> </div> <div class='t396__elem tn-elem tn-elem__5487039881666720340242' data-elem-id='1666720340242' data-elem-type='text' data-field-top-value="370" data-field-left-value="381" data-field-width-value="439" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="273" data-field-left-res-320-value="26" data-field-width-res-320-value="268" data-field-top-res-480-value="297" data-field-left-res-480-value="67" data-field-width-res-480-value="346" data-field-top-res-640-value="319" data-field-left-res-640-value="105" data-field-top-res-960-value="325" data-field-left-res-960-value="265" data-field-width-res-960-value="431"><div class='tn-atom' field='tn_text_1666720340242'>В ближайшее время наш менеджер свяжется с Вами.</div> </div> <div class='t396__elem tn-elem tn-elem__5487039881666720384225' data-elem-id='1666720384225' data-elem-type='shape' data-field-top-value="141" data-field-left-value="286" data-field-height-value="369" data-field-width-value="629" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px" data-field-top-res-320-value="131" data-field-left-res-320-value="5" data-field-height-res-320-value="223" data-field-width-res-320-value="310" data-field-top-res-480-value="129" data-field-left-res-480-value="9" data-field-height-res-480-value="265" data-field-width-res-480-value="463" data-field-top-res-640-value="119" data-field-left-res-640-value="48" data-field-top-res-960-value="124" data-field-left-res-960-value="208" data-field-height-res-960-value="313" data-field-width-res-960-value="545"><div class='tn-atom'></div></div>
                </div>
            </div>
            <script>t_onReady(function () {
                    t_onFuncLoad('t396_init', function () {
                        t396_init('548703988');
                    });
                });</script><!-- /T396 -->
        </div>
        
   
        
        
    </div><!--/allrecords--><!-- Tilda copyright. Don't remove this line --><div class="t-tildalabel " id="tildacopy" data-tilda-sign="6786950#33953345"><a href="https://tilda.cc/?upm=6786950" class="t-tildalabel__link"><div class="t-tildalabel__wrapper"><div class="t-tildalabel__txtleft">Made on </div><div class="t-tildalabel__wrapimg"><img src="thsfiles/images/tildacopy.png" class="t-tildalabel__img" fetchpriority="low"></div><div class="t-tildalabel__txtright">Tilda</div></div></a></div><!-- Stat -->
    <script type="text/javascript">if (!window.mainTracker) { window.mainTracker = 'tilda'; }
        setTimeout(function () {
            (function (d, w, k, o, g) { var n = d.getElementsByTagName(o)[0], s = d.createElement(o), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.key = k; s.id = "tildastatscript"; s.src = g; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, '9a1623bb4a5fb40c47cdb4ada62a097f', 'script', 'js/tilda-stat-1.0.min.js');
        }, 2000);</script>
        <style>
    #allrecords + div {
    height: 0!important;
    transform: scale(0);
}

</style>
</body>
</html>

<img height="1" width="1" src="https://www.facebook.com/tr?id=571043014816258&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=3264777510501435&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=784245229970842&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=544123947830073&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=916814429441593&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=906972650629097&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=951440876213504&ev=Lead&noscript=1" />
<img height="1" width="1" src="https://www.facebook.com/tr?id=1309461126564419&ev=Lead&noscript=1" />