let theWheel = new Winwheel({
  numSegments: 8, // Specify number of segments.
  outerRadius: 300, // Set outer radius so wheel fits inside the background.
  // drawMode: "image", // drawMode must be set to image.
  drawText: true, // Need to set this true if want code-drawn text on image wheels.
  textFontSize: 36, // Set text options as desired.
  textOrientation: "curved",
  textDirection: "vertical",
  textAlignment: "outer",
  textMargin: 40,
  textFontFamily: "Monospace ",
  textStrokeStyle: "black",
  textLineWidth: 1,
  textFillStyle: "darkblue",

  // Define segments.
  // Specify pointer guide properties.

  segments: [
    {
      textFontWeight: 800,
      fillStyle: "#1475e1",
      text: "25\nFREE\nSPINS",
    },
    { textFontWeight: 600, fillStyle: "#fff", text: "$100,000\nPRIZES" },
    { textFontWeight: 600, fillStyle: "#1475e1", text: "\n10 €" },
    {
      textFontWeight: 600,
      fillStyle: "#fff",
      text: "100\nFREE\nSPINS",
    },
    {
      textFontWeight: 600,
      fillStyle: "#1475e1",
      text: "X2\nYOUR\nDEPOSIT",
    },
    {
      textFontWeight: 600,
      fillStyle: "#fff",
      text: "X5\nYOUR\nDEPOSIT",
    },
    { textFontWeight: 600, fillStyle: "#1475e1", text: "\n5 €" },
    { textFontWeight: 600, fillStyle: "#fff", text: "SPIN\nAGAIN" },
  ],

  // Specify the animation to use.
  animation: {
    type: "spinToStop",
    duration: 5, // Duration in seconds.
    spins: 8, // Number of complete spins.
    callbackFinished: alertPrize,
    // callbackSound: playSound, // Function to call when the tick sound is to be triggered.
    // soundTrigger: "pin", // Specify pins are to trigger the sound, the other option is 'segment'.
  },
  pins: {
    number: 8, // Number of pins. They space evenly around the wheel.
  },
});
theWheel.segments[1].textFillStyle = "#FFFFFF";
theWheel.segments[3].textFillStyle = "#FFFFFF";
theWheel.segments[5].textFillStyle = "#FFFFFF";
theWheel.segments[7].textFillStyle = "#FFFFFF";
theWheel.draw();
// -----------------------------------------------------------------
// This function is called when the segment under the prize pointer changes
// we can play a small tick sound here like you would expect on real prizewheels.
// -----------------------------------------------------------------
let audio = new Audio("img/soundwheel.mp3"); // Create audio object and load tick.mp3 file.

function playSound() {
  // Stop and rewind the sound if it already happens to be playing.
  audio.pause();
  audio.currentTime = 0;

  // Play the sound.
  audio.play();
}

// Function with formula to work out stopAngle before spinning animation.
// Called from Click of the Spin button.
function calculatePrize() {
  // This formula always makes the wheel stop somewhere inside prize 3 at least
  // 1 degree away from the start and end edges of the segment.
  let stopAt = 51 + Math.floor(Math.random() * 39);

  // Important thing is to set the stopAngle of the animation before stating the spin.
  theWheel.animation.stopAngle = stopAt;

  // May as well start the spin from here.
  theWheel.startAnimation();
}
// Create new image object in memory.
let loadedImg = new Image();

// Create callback to execute once the image has finished loading.
loadedImg.onload = function () {
  theWheel.wheelImage = loadedImg; // Make wheelImage equal the loaded image object.
  theWheel.draw(); // Also call draw function to render the wheel.
};

// Set the image source, once complete this will trigger the onLoad callback (above).
loadedImg.src = "img/wheelblank.png";

// Vars used by the code in this page to do power controls.
let wheelPower = 0;
let wheelSpinning = false;
// -------------------------------------------------------
// Function to handle the onClick on the power buttons.
// -------------------------------------------------------
function powerSelected(powerLevel) {
  // Ensure that power can't be changed while wheel is spinning.
  if (wheelSpinning == false) {
    // Reset all to grey incase this is not the first time the user has selected the power.
    document.getElementById("pw1").className = "";
    document.getElementById("pw2").className = "";
    document.getElementById("pw3").className = "";

    // Now light up all cells below-and-including the one selected by changing the class.
    if (powerLevel >= 1) {
      document.getElementById("pw1").className = "pw1";
    }

    if (powerLevel >= 2) {
      document.getElementById("pw2").className = "pw2";
    }

    if (powerLevel >= 3) {
      document.getElementById("pw3").className = "pw3";
    }

    // Set wheelPower var used when spin button is clicked.
    wheelPower = powerLevel;

    // Light up the spin button by changing it's source image and adding a clickable class to it.
    document.getElementById("spin_button").src = "img/newspin.png";
    document.getElementById("spin_button").className = "clickable";
  }
}

// -------------------------------------------------------
// Click handler for spin button.
// -------------------------------------------------------
let defaultPowerLevel = 1;
let wheelContainer = document.querySelector(".the_wheel");
let isBlinking = false;
let intervalId;

function startSpin() {
  calculatePrize();
  playSound();

  // Ensure that spinning can't be clicked again while already running.
  if (wheelSpinning == false) {
    // Based on the power level selected adjust the number of spins for the wheel, the more times is has
    // to rotate with the duration of the animation the quicker the wheel spins.
    if (wheelPower == 1) {
      theWheel.animation.spins = 2;
    } else if (wheelPower == 2) {
      theWheel.animation.spins = 5;
    } else if (wheelPower == 3) {
      theWheel.animation.spins = 8;
    }

    // Begin the spin animation by calling startAnimation on the wheel object.
    theWheel.startAnimation();

    // Set to true so that power can't be changed and spin button re-enabled during
    // the current animation. The user will have to reset before spinning again.
    wheelSpinning = true;
  }
}

// -------------------------------------------------------
// Function for reset button.
// -------------------------------------------------------
function resetWheel() {
  theWheel.stopAnimation(false); // Stop the animation, false as param so does not call callback function.
  theWheel.rotationAngle = 0; // Re-set the wheel angle to 0 degrees.
  theWheel.draw(); // Call draw to render changes to the wheel.

  wheelSpinning = false; // Reset to false to power buttons and spin can be clicked again.
}

// -------------------------------------------------------
// Called when the spin animation has finished by the callback feature of the wheel because I specified callback in the parameters
// note the indicated segment is passed in as a parmeter as 99% of the time you will want to know this to inform the user of their prize.
// -------------------------------------------------------

function showPopup() {
  // Get the popup element
  const popup = document.querySelector(".overlay");
  // Show the popup by changing its display style
  popup.style.display = "block";
}

// Function called when the spin finishes (from your existing code)
function alertPrize(indicatedSegment) {
  // Do something with the indicatedSegment if needed
  // ...
  // Show the popup after the spin finishes
}
function alertPrize(indicatedSegment) {
  // Do whatever logic you need based on the indicated segment.
  // Then, open the popup when the wheel spin finishes
  showPopup();
}
