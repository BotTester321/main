let timer = 0.1 * 100 * 60; // 24 hours in seconds

function updateTimerValues() {
  let hours = Math.floor(timer / 3600);
  let minutes = Math.floor((timer % 3600) / 60);
  let seconds = timer % 60;

  document.getElementById("hoursText").textContent = padValue(hours);
  document.getElementById("minutesText").textContent = padValue(minutes);
  document.getElementById("secondsText").textContent = padValue(seconds);
}

function padValue(value) {
  return value < 10 ? `0${value}` : `${value}`;
}

function countdown() {
  updateTimerValues();
  if (timer > 0) {
    timer--;
    setTimeout(countdown, 1000); // Update every second
  }
}

countdown(); // Start the countdown
